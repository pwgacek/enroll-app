create function get_used_etcs(student_id bigint) returns integer
    language plpgsql
as
$$
declare
        used_etcs smallint;
    begin
        if not contains_student_id(student_id) then
            raise exception 'Student not found';
        end if;
        select into used_etcs sum(c.etcs) from courses as c
            inner join students_courses sc on c.courseid = sc.courses_courseid
        where sc.students_studentid = student_id;
        if used_etcs is null then
            return 0;
        end if;
        return used_etcs;
    end;
$$;

alter function get_used_etcs(bigint) owner to postgres;

