create function enroll_trigger_function() returns trigger
    language plpgsql
as
$$
declare
        chosen_course courses%rowtype;
BEGIN
    if no_available_places(new.courses_courseid) = 0 then
        raise exception 'no available place';
end if;
    if collision_exists(new.students_studentid,new.courses_courseid) then
        raise exception 'schedule collision';
    end if;
    select into chosen_course * from courses as c where c.courseid = new.courses_courseid;
    if get_used_etcs(new.students_studentid) + chosen_course.etcs > 30 then
        raise exception 'not enough etcs';
    end if;
    return new;
end
$$;

alter function enroll_trigger_function() owner to postgres;

