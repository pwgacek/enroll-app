create function no_available_places(course_id integer) returns smallint
    language plpgsql
as
$$
DECLARE
    takenPlaces integer;
    totalPlaces integer;

Begin
    if not exists(select * from courses as c where course_id = c.courseid) then
        raise exception 'Course not found';
    end if;
    select c.numberofplaces into totalPlaces from courses as c where c.courseid = course_id limit 1;

    select COUNT(*) into takenPlaces from students_courses as sc where sc.courses_courseid = course_id;

    return totalPlaces - takenPlaces;
end
$$;

alter function no_available_places(integer) owner to postgres;

