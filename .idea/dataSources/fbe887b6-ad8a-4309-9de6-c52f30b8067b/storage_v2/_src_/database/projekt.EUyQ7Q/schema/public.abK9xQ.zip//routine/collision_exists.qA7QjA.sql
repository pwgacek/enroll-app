create function collision_exists(student_id integer, course_id integer) returns boolean
    language plpgsql
as
$$
declare
        chosen_course courses%rowtype;
        no_collisions smallint;

    begin
        if not contains_student_id(student_id) then
            raise exception 'student not found';
        end if;
        select into chosen_course * from courses as c where c.courseid = course_id limit 1;
        if chosen_course is null then
            raise exception 'course not found';
        end if;

        select into no_collisions count(c.*) from courses as c inner join students_courses sc on c.courseid = sc.courses_courseid
        where sc.students_studentid = student_id and c.weekday = chosen_course.weekday
          and not (c.endtime < chosen_course.starttime or chosen_course.endtime < c.starttime ) ;

        if no_collisions = 0 then 
            return false;
        end if;
        return true;

    end;
$$;

alter function collision_exists(integer, integer) owner to postgres;

