create function contains_student_id(student_id bigint) returns boolean
    language plpgsql
as
$$
declare
    student students%ROWTYPE;
BEGIN
select  * into student from students  where studentid = student_id limit 1;
if student is null THEN
    return false;
end if;
return true;

end
$$;

alter function contains_student_id(bigint) owner to postgres;

