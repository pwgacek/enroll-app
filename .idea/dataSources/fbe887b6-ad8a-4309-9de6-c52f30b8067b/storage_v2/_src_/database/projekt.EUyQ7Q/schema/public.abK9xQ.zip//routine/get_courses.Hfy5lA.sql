create function get_courses(student_id bigint) returns SETOF courses
    language plpgsql
as
$$
declare
	ids smallint[];
	student students%rowtype;
begin
	select  * into student from students as s where student_id = s.studentid;
	if student is null then
        raise exception 'Student not found';
    end if;
	 select ARRAY(select sf.faculties_facultyid from students_faculties as sf where sf.students_studentid = student_id) into ids;

	return query
		select * from courses as c
		where c.semester = student.semester and c.faculty_facultyid = any(ids);
end
$$;

alter function get_courses(bigint) owner to postgres;

