create function is_student_enrolled(student_id integer, course_id integer) returns boolean
    language plpgsql
as
$$
declare
    enrollment students_courses%ROWTYPE;
begin
    select * into enrollment from students_courses as sc
    where sc.students_studentid = student_id and sc.courses_courseid = course_id;

    if enrollment is null then
        return false;
    end if;
    return true;
end;
$$;

alter function is_student_enrolled(integer, integer) owner to postgres;

